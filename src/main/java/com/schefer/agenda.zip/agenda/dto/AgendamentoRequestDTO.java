package com.schefer.agenda.dto;

public record AgendamentoRequestDTO(

) {
}
