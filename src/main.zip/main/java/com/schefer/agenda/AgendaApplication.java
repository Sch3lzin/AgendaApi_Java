package com.schefer.agenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaApplication {

	public static void main(String[] args) {
        System.out.println("Hello World!");
		SpringApplication.run(AgendaApplication.class, args);
	}

}
